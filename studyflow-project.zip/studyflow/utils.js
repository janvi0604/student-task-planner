// ── SHARED UTILITIES ─────────────────────────────────

// LocalStorage helpers
function getLS(key, def) {
  try { return JSON.parse(localStorage.getItem(key)) || def; }
  catch { return def; }
}
function setLS(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

// Escape HTML
function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Toast notification
function showToast(msg, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const t = document.createElement('div');
  t.className = `toast${type === 'error' ? ' error' : ''}`;
  t.textContent = msg;
  container.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// Live clock
function startClock() {
  const el = document.getElementById('live-clock');
  if (!el) return;
  const tick = () => el.textContent = new Date().toLocaleTimeString('en-US', { hour12: false });
  tick();
  setInterval(tick, 1000);
}

// Set active nav link
function setActiveNav() {
  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    const href = a.getAttribute('href');
    if (href === page || (page === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });
}

// Stats update (used on multiple pages)
function updateStats() {
  const tasks = getLS('sf_tasks', []);
  const sessions = getLS('sf_sessions', []);
  const done = tasks.filter(t => t.done).length;
  const el = (id, val) => { const e = document.getElementById(id); if(e) e.textContent = val; };
  el('stat-total', tasks.length);
  el('stat-done', done);
  el('stat-pending', tasks.length - done);
  el('stat-sessions', sessions.length);
}

// Fetch motivational quote
async function fetchQuote() {
  const textEl   = document.getElementById('quote-text');
  const authorEl = document.getElementById('quote-author');
  if (!textEl) return;
  textEl.textContent = 'Fetching inspiration...';
  authorEl && (authorEl.textContent = '');
  try {
    const res  = await fetch('https://quotes-api-self.vercel.app/quote');
    if (!res.ok) throw new Error();
    const data = await res.json();
    textEl.textContent  = data.quote || data.content || 'Believe in yourself!';
    authorEl && (authorEl.textContent = '— ' + (data.author || 'Unknown'));
  } catch {
    const fallback = [
      { q: "The secret of getting ahead is getting started.", a: "Mark Twain" },
      { q: "Education is the most powerful weapon to change the world.", a: "Nelson Mandela" },
      { q: "Study hard in the most undisciplined, irreverent and original manner possible.", a: "Richard Feynman" },
      { q: "Success is the sum of small efforts, repeated day in and day out.", a: "Robert Collier" },
      { q: "The expert in anything was once a beginner.", a: "Helen Hayes" },
    ];
    const pick = fallback[Math.floor(Math.random() * fallback.length)];
    textEl.textContent  = pick.q;
    authorEl && (authorEl.textContent = '— ' + pick.a);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  startClock();
  setActiveNav();
});
